// 名字生成逻辑
const firstNames = {
    '张': ['James', 'Jack', 'Jason', 'Justin', 'Jacob'],
    '李': ['Leo', 'Lucas', 'Liam', 'Logan', 'Louis'],
    '王': ['William', 'Wade', 'Wesley', 'Walter', 'Warren'],
    '陈': ['Charles', 'Chris', 'Calvin', 'Carl', 'Cameron'],
    '林': ['Leonard', 'Lewis', 'Lance', 'Lawrence', 'Luke'],
    '刘': ['Larry', 'Louis', 'Leon', 'Lionel', 'Lloyd'],
    '黄': ['Henry', 'Howard', 'Harry', 'Hugh', 'Harold'],
    '吴': ['Wayne', 'Wilson', 'Wyatt', 'Wallace', 'Wade'],
    '周': ['Zachary', 'Zion', 'Zack', 'Zeus', 'Zane'],
    '徐': ['Xavier', 'Xander', 'Xerxes', 'Xico', 'Xiomar']
};

const lastNames = [
    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones',
    'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez',
    'Anderson', 'Taylor', 'Thomas', 'Moore', 'Jackson',
    'Martin', 'Lee', 'Thompson', 'White', 'Harris'
];

const meanings = {
    'James': '源自希伯来语，意为"上帝的恩赐"',
    'Leo': '源自拉丁语，意为"狮子"',
    'William': '源自日耳曼语，意为"坚定的保护者"',
    'Charles': '源自日耳曼语，意为"自由人"',
    'Leonard': '源自日耳曼语，意为"勇猛如狮"',
    'Larry': '源自拉丁语，意为"桂冠"',
    'Henry': '源自日耳曼语，意为"统治者"',
    'Wayne': '源自盎格鲁撒克逊语，意为"制车人"',
    'Zachary': '源自希伯来语，意为"上帝记得"',
    'Xavier': '源自巴斯克语，意为"新房子"'
};

// API参数配置
const API_ENDPOINT = 'https://api.siliconflow.cn/v1/chat/completions';
const MODEL_NAME = 'Pro/deepseek-ai/DeepSeek-R1';  // 使用正确的模型名称
const API_KEY = 'sk-zdonnlmvneeywanlpjyvdiwvvwrcsrwovktugsojsipwtvpr';

// 生成名字的核心函数
async function generateNames() {
    const chineseName = document.getElementById('nameInput').value.trim();
    if (!chineseName) {
        return showError('请输入中文姓名');
    }

    const requestBody = {
        model: MODEL_NAME,
        messages: [{
            role: 'system',
            content: '你是一个专业的英文起名专家，擅长将中文名字转换为富有创意的英文名。请用中文回复。'
        }, {
            role: 'user',
            content: `请根据中文名「${chineseName}」生成5个欧美风格的英文名，要求：
            1. 结合名字本意和发音
            2. 包含幽默文化元素
            3. 每个名字附带中英文解释
            4. 使用Markdown格式返回`
        }],
        temperature: 0.8,
        top_p: 0.95,
        max_tokens: 2000,
        stream: false
    };

    try {
        // 添加加载提示
        const resultsDiv = document.getElementById('results');
        resultsDiv.innerHTML = '<div class="loading">正在生成名字，请稍候...</div>';
        resultsDiv.style.display = 'block';

        console.log('发送请求到API:', {
            url: API_ENDPOINT,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            body: JSON.stringify(requestBody, null, 2)
        });

        const response = await fetch(API_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            body: JSON.stringify(requestBody)
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            const errorDetails = {
                status: response.status,
                statusText: response.statusText,
                errorData: JSON.stringify(errorData, null, 2),
                requestBody: JSON.stringify(requestBody, null, 2),
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + API_KEY.substring(0, 10) + '...'
                }
            };
            console.error('API错误详情:', errorDetails);
            throw new Error(errorData.error?.message || `请求失败: ${response.status} ${response.statusText}\n${JSON.stringify(errorData, null, 2)}`);
        }

        const data = await response.json();
        console.log('API响应数据:', data);

        if (data.choices && data.choices[0] && data.choices[0].message) {
            displayResults(data.choices[0].message.content);
        } else {
            console.error('API返回数据格式错误:', data);
            throw new Error('返回数据格式错误');
        }
    } catch (error) {
        console.error('捕获到错误:', error);
        console.error('错误堆栈:', error.stack);
        showError(error.message || '生成失败，请检查网络连接');
        // 清除加载提示
        const resultsDiv = document.getElementById('results');
        resultsDiv.style.display = 'none';
    }
}

// 结果显示函数
function displayResults(markdownContent) {
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = marked.parse(markdownContent);
    resultsDiv.style.display = 'block';
}

// 错误处理函数
function showError(message) {
    const errorDiv = document.getElementById('error');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 3000);
}

// 获取随机文化引用
function getRandomCulturalReference(name) {
    const references = [
        `像${name} Bond一样充满神秘感和魅力`,
        `如同${name} Potter般充满魔力`,
        `犹如${name} Stark般智慧与勇气并存`,
        `宛如${name} Gatsby般浪漫而深邃`,
        `如${name} Parker一样机智幽默`,
        `像${name} Wayne般正义感十足`,
        `如同${name} Holmes般睿智聪明`,
        `犹如${name} Skywalker般充满冒险精神`,
        `宛如${name} Baggins般勇敢而忠诚`,
        `像${name} Sparrow般独特而难忘`
    ];
    return references[Math.floor(Math.random() * references.length)];
}

// 获取发音提示
function getPronounciation(firstName, lastName) {
    return `${firstName}（${getChinesePronunciation(firstName)}）${lastName}（${getChinesePronunciation(lastName)}）`;
}

// 获取中文发音提示
function getChinesePronunciation(name) {
    const pronunciations = {
        'James': '杰姆斯',
        'Leo': '利奥',
        'William': '威廉',
        'Charles': '查尔斯',
        'Leonard': '莱昂纳德',
        'Larry': '拉里',
        'Henry': '亨利',
        'Wayne': '韦恩',
        'Zachary': '扎克瑞',
        'Xavier': '泽维尔',
        'Smith': '史密斯',
        'Johnson': '约翰逊',
        'Williams': '威廉姆斯',
        'Brown': '布朗',
        'Jones': '琼斯'
    };
    return pronunciations[name] || name;
}
